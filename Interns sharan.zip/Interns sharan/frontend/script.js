document.getElementById("screenshot-btn").addEventListener("click", () => {
  console.log("Button clicked!");

  const target = document.querySelector(".infographic-container"); // or document.body for full page

  html2canvas(target).then((canvas) => {
    const base64image = canvas.toDataURL("image/png");

    fetch("http://localhost:4000/screenshot", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ image: base64image }),
    })
      .then((response) => response.json())
      .then((data) => {
        alert("Screenshot saved: " + data.fileName);
      })
      .catch((error) => {
        alert("Error sending screenshot: " + error);
      });
  });
});
