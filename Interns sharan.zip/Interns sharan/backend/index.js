// index.js

import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const app = express();
const port = 4000;

// Workaround to use __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Middlewares
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Ensure screenshots directory exists
const screenshotDir = path.join(__dirname, 'screenshots');
if (!fs.existsSync(screenshotDir)) {
  fs.mkdirSync(screenshotDir);
}

// Route to handle screenshot saving
app.post('/screenshot', (req, res) => {
  const { image } = req.body;

  if (!image) {
    return res.status(400).json({ message: 'No image provided' });
  }

  // Extract base64 data
  const base64Data = image.replace(/^data:image\/png;base64,/, '');

  const fileName = `screenshot-${new Date()
    .toISOString()
    .replace(/[:.]/g, '-')}.png`;

  const filePath = path.join(screenshotDir, fileName);

  fs.writeFile(filePath, base64Data, 'base64', (err) => {
    if (err) {
      console.error('❌ Failed to save screenshot:', err);
      return res.status(500).json({ message: 'Failed to save screenshot' });
    }

    console.log(`✅ Screenshot saved: ${fileName}`);
    res.json({ message: 'Screenshot saved successfully', fileName });
  });
});

app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
